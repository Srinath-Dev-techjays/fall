package com.example.falldetection

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.DecimalFormat


class MainActivity : AppCompatActivity(), SensorEventListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        val  accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val magneticFieldSensor = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        sensorManager.registerListener(this, accelerometerSensor, SensorManager.SENSOR_DELAY_NORMAL)
        sensorManager.registerListener(this, magneticFieldSensor, SensorManager.SENSOR_DELAY_NORMAL)
    }

    override fun onSensorChanged(foEvent: SensorEvent?) {
        if (foEvent!!.sensor.getType() === Sensor.TYPE_ACCELEROMETER) {
            val loX: Double = foEvent!!.values.get(0).toDouble()
            val loY: Double = foEvent.values.get(1).toDouble()
            val loZ: Double = foEvent.values.get(2).toDouble()
            val loAccelerationReader = Math.sqrt(
                Math.pow(loX, 2.0)
                        + Math.pow(loY, 2.0)
                        + Math.pow(loZ, 2.0)

            )
            val precision = DecimalFormat("0.00")
            val ldAccRound: Double = precision.format(loAccelerationReader).toDouble()
            if (ldAccRound > 0.3 && ldAccRound < 0.5) {
               Toast.makeText(this,"Fall working value: ${ldAccRound}",Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {

    }
}